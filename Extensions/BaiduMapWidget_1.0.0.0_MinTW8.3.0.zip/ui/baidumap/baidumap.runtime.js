﻿TW.Runtime.Widgets.baidumap = function () {
    "use strict";
    var thisWidget = this;
    var infoWindow = undefined;
	var userHasPannedOrZoomedSinceAutoZoom = false;
	var initialData = true;
	var weAreChangingBounds = false;
	var autoZoomBehavior = 'every-data-change';
    var regionInfoWindow = undefined;
    var lastRegionNumber = undefined;
    var lastData = undefined;
    var lastRegionData = undefined;
    var infoId = 'MapInfoWindow' + TW.uniqueId();
    var tooltipMashupWidth = 100;
    var tooltipMashupHeight = 100;
    var isMashupTooltipConfigured = false;
    var isRegionTooltipConfigured = false;
    var dataInfotable = undefined;

    function createIcon(json){
        var icon = new BMap.Icon(json.image, new BMap.Size(json.w,json.h),{imageOffset: new BMap.Size(-json.l,-json.t),infoWindowOffset:new BMap.Size(json.lb+5,1),offset:new BMap.Size(json.x,json.h)});
        return icon;
    }

    function autofitMap() {
        thisWidget.map.setViewport(thisWidget.getAllPoints());
    }

    this.runtimeProperties = function () {
        return {
	        'supportsAutoResize': true,
            'needsDataLoadingAndError': true,
            'propertyAttributes': {
                'TooltipLabel1': {'isLocalizable': true},
                'TooltipLabel2': {'isLocalizable': true},
                'TooltipLabel3': {'isLocalizable': true},
                'TooltipLabel4': {'isLocalizable': true},
                'RegionTooltipLabel1': {'isLocalizable': true},
                'RegionTooltipLabel2': {'isLocalizable': true},
                'RegionTooltipLabel3': {'isLocalizable': true},
                'RegionTooltipLabel4': {'isLocalizable': true}
            }
        };
    };

    this.setSelectedMarker = function (selectedRow) {

        var isMultiselect = thisWidget.properties['MultiSelect'];

        var selMarker;

        for (var markerNo = 0; markerNo < thisWidget.currentMarkers.length; markerNo++) {
            var currentMarker = thisWidget.currentMarkers[markerNo];
            if (currentMarker.rowNumber === selectedRow) {
                selMarker = currentMarker;
                break;
            }
        }

        if (selMarker !== undefined) {
            if (selMarker._isSelected) {
                if (isMultiselect) {
                    TW.removeElementFromArray(thisWidget.selectedRows, selectedRow);
                    selMarker._isSelected = false;
                    selMarker.setIcon(selMarker._assignedIcon);
                    if (!thisWidget.ignoreSelectionEvent) {
                        thisWidget.updateSelection('Data', thisWidget.selectedRows);
                    }
                }
            }
            else {
                if (!isMultiselect) {
                    thisWidget.clearSelectedMarkers();
                    thisWidget.selectedRows = [selectedRow];
                }
                else
                    thisWidget.selectedRows.push(selectedRow);
				
                selMarker.setIcon(thisWidget.selectedMarker.getIcon());
                selMarker._isSelected = true;

                if (!thisWidget.ignoreSelectionEvent) {
                    thisWidget.updateSelection('Data', thisWidget.selectedRows);
                }
            }
        }
    };

    function handleMarkerMouseover (e) {
        var thisMarker = this;

        if (!isMashupTooltipConfigured) {
            return;
        }

        var selectedRowNo = thisMarker.rowNumber;

        TW.log.info('Should display info for Row #' + selectedRowNo);

        thisWidget.cleanupTooltipMashup();

        infoWindow.setContent('<div id="' + infoId + '" style="width:' + tooltipMashupWidth + 'px;height:' + tooltipMashupHeight + 'px;">Loading Tooltip Mashup...</div>');
        thisMarker.openInfoWindow(infoWindow);

        setTimeout(function () {
            var mashupSpec = {};
            mashupSpec.mashupName = thisWidget.getProperty('TooltipMashupName');
            mashupSpec.mashupParameters = {};

            var mashupParameters = thisWidget.properties['MashupParameters'];
            if (mashupParameters === undefined)
                mashupParameters = [];

            var nParams = mashupParameters.length;

            for (var paramNo = 0; paramNo < nParams; paramNo++) {
                var paramInfo = mashupParameters[paramNo],
                    propName = paramInfo.ParameterName,
                    fldName = thisWidget.getProperty(propName),
                    propValue;
                if (fldName === 'ALL_FIELDS') {
                    propValue = JSON.parse(JSON.stringify(dataInfotable));
                    propValue.rows.push(lastData[selectedRowNo]);
                } else {
                    propValue = lastData[selectedRowNo][thisWidget.getProperty(propName)];
                }
                if (propValue !== undefined) {
                    mashupSpec.mashupParameters[propName] = propValue;
                }
            }

            $('#' + infoId).mashup(mashupSpec);
        }, 100);
    };

    function handleMarkerClick (e) {
        var thisMarker = this;
        thisWidget.setSelectedMarker(thisMarker.rowNumber);
    }

    function handleMarkerDoubleClick (e) {

        thisWidget.jqElement.triggerHandler('DoubleClicked');
    }

	this.resize = function(width,height) {
	};

    this.renderHtml = function () {

        tooltipMashupWidth = thisWidget.getProperty('TooltipMashupWidth');
        tooltipMashupHeight = thisWidget.getProperty('TooltipMashupHeight');
	    var oldAutoZoom = this.getProperty('AutoZoom');
	    autoZoomBehavior =  this.getProperty('AutoZoomBehavior');
	    switch( autoZoomBehavior ) {
		    case 'disable-on-user-pan-zoom':
		    case 'only-when-autozoom-invoked':
	        case 'only-initial-data':
			    // leave these alone
			    break;
		    default:
			    // anything else, default to our old behavior
			    if( oldAutoZoom === undefined || oldAutoZoom === true )  {
				    autoZoomBehavior = 'every-data-change';
			    } else if( oldAutoZoom === false ) {
				    autoZoomBehavior = 'only-when-autozoom-invoked';
			    } else {
				    autoZoomBehavior = 'every-data-change';
			    }
			    break;
	    }

        var mashupName = thisWidget.getProperty('TooltipMashupName');
        if (mashupName !== undefined && mashupName.length > 0) {
            isMashupTooltipConfigured = true;
        }

        try {
            if (window.BMap !== undefined && window.BMap !== null) {
                this.haveBaiduMap = true;
            }
        }
        catch (errmsg) {
        }

        if (this.haveBaiduMap)
		{
            return '<div class="widget-content widget-map-runtime"></div>';
		}
        else
            return '<div class="widget-content widget-map-runtime"><span class="textsize-large">Baidu Map is Not Available</span></div>';
    };

    this.haveBaiduMap = false;
    this.ignoreSelectionEvent = false;
    this.map = undefined;
    this.selectionMarker = null;
	this.selectedMarker = null;
    this.startMarker = null;
    this.endMarker = null;
	this.markerWidth = 0;
	this.markerHeight = 0;
    this.polyline = null;
    this.routePolyline = null;
    this.plannedRoutePolyline = null;
    this.dataBounds;
    this.plannedRouteDataBounds;
    this.routeDataBounds;
    this.regionDataBounds;
    this.lastBounds;
    this.lastZoom;
    this.markerLookup = new Array();
    this.currentMarkers = [];
    this.selectedRows = new Array();
    this.currentRegions = new Array();
    this.selectedRegionRows = new Array();
    this.markerStyle;
    this.selectedMarkerStyle;
    this.selectionMarkerStyle;
    this.startMarkerStyle;
    this.endMarkerStyle;
    this.pathStyle;
    this.routeStyle;
    this.plannedRouteStyle;
    this.regionStyle;
    this.positionData = [];
    this.routeData = [];
    this.plannedRouteData = [];
    this.regionData = [];
    this.regionLocationData = [];

    this.clearSelectedMarkers = function () {
        thisWidget.selectedRows = [];
        for (var markerNo = 0; markerNo < thisWidget.currentMarkers.length; markerNo++) {
            var currentMarker = thisWidget.currentMarkers[markerNo];
            currentMarker._isSelected = false;
            currentMarker.setIcon(currentMarker._assignedIcon);
        }
    };

    this.afterRender = function () {

        this.markerStyle = TW.getStyleFromStyleDefinition(this.getProperty('MarkerStyle'));
        this.selectionMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('SelectionMarkerStyle'));
        this.selectedMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('SelectedMarkerStyle'));
        this.startMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('StartMarkerStyle'));
        this.endMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('EndMarkerStyle'));
		this.markerWidth = this.getProperty('MarkerWidth', 32);
		this.markerHeight = this.getProperty('MarkerHeight', 32);
        this.pathStyle = TW.getStyleFromStyleDefinition(this.getProperty('PathStyle'));
        this.plannedRouteStyle = TW.getStyleFromStyleDefinition(this.getProperty('PlannedRouteStyle'));
        this.routeStyle = TW.getStyleFromStyleDefinition(this.getProperty('RouteStyle'));
        this.regionStyle = TW.getStyleFromStyleDefinition(this.getProperty('RegionStyle'));
        this.selectedRegionStyle = TW.getStyleFromStyleDefinition(this.getProperty('SelectedRegionStyle'));

        var zoom = parseInt(this.getProperty('Zoom'));

        var centerPosition = new BMap.Point(116.3917,39.9139);

        if (this.getProperty('SelectedLocation') !== undefined) {
            centerPosition = new BMap.Point(this.getProperty('SelectedLocation').latitude, this.getProperty('SelectedLocation').longitude);
        }

        var mapOpt = {};

        if (thisWidget.getProperty('MapType', 'normal') == 'normal') {
            mapOpt.mapType = BMAP_NORMAL_MAP;
        } else if (thisWidget.getProperty('MapType') == 'satellite') {
            mapOpt.mapType = BMAP_SATELLITE_MAP;
        } else if (thisWidget.getProperty('MapType') == 'hybrid') {
            mapOpt.mapType = BMAP_HYBRID_MAP;
        } else if (thisWidget.getProperty('MapType') == 'perspective') {
            mapOpt.mapType = BMAP_PERSPECTIVE_MAP;
        }
        
        var mapStyle = {};
        mapStyle.style = thisWidget.getProperty('MapStyle', 'normal');

        if (this.haveBaiduMap) {
            var map = this.map = new BMap.Map(thisWidget.jqElementId, mapOpt);
            map.enableAutoResize();
            map.setMapStyle(mapStyle);

            if (thisWidget.getProperty('EnableLocationSelection')) {
                map.disableDoubleClickZoom();

                map.addEventListener("dblclick", function(e){
                    var location = new Object();
                    location.units = "WGS84";
                    location.elevation = 0.0;
                    location.latitude = e.point.lat;
                    location.longitude = e.point.lng;

                    thisWidget.moveSelectionMarker(location);
                    thisWidget.setProperty('SelectedLocation', location);
                    thisWidget.jqElement.triggerHandler('Changed');
                });

            } else {
                map.enableDoubleClickZoom();
            }

            infoWindow = new BMap.InfoWindow();
            regionInfoWindow = new BMap.InfoWindow();

            map.centerAndZoom(centerPosition, zoom);
            map.enableScrollWheelZoom();
            map.enableContinuousZoom();
            map.enablePinchToZoom();
            map.addControl(new BMap.NavigationControl({type: BMAP_NAVIGATION_CONTROL_SMALL}));
            map.addControl(new BMap.MapTypeControl());

			if (thisWidget.getProperty('EnableMarkerSelection') === true) {
				var iconImg = createIcon({ image:thisWidget.selectedMarkerStyle.image, w:thisWidget.markerWidth, h:thisWidget.markerHeight, l:0, t:0, x:6, lb:5 });
                var selMarkerOpt = {
                    icon: iconImg,
                    title: "Selected"
                };

                thisWidget.selectedMarker = new BMap.Marker(centerPosition, selMarkerOpt);
                map.addOverlay(thisWidget.selectedMarker);
			}
			
            if (thisWidget.getProperty('ShowSelectionMarker') === true) {
                var iconImg = createIcon({ image:thisWidget.selectionMarkerStyle.image, w:thisWidget.markerWidth, h:thisWidget.markerHeight, l:0, t:0, x:6, lb:5 });
                var selMarkerOpt = {
                    icon: iconImg,
                    title: "Selection"
                };

                thisWidget.selectionMarker = new BMap.Marker(centerPosition, selMarkerOpt);
                map.addOverlay(thisWidget.selectionMarker);
            }
        }
        
        
        thisWidget.addEventListener("FilteredDataBoundByView", function(e){
        	
        	var bounds = this.dataBounds = new BMap.Bounds();
        	
        	var changed = false;

        	if(thisWidget.lastBounds !== undefined) {
        		if(thisWidget.lastBounds.getNorthEast().lat() != bounds.getNorthEast().lat())
        			changed = true;
        		if(thisWidget.lastBounds.getNorthEast().lng() != bounds.getNorthEast().lng())
        			changed = true;
        		if(thisWidget.lastBounds.getSouthWest().lat() != bounds.getSouthWest().lat())
        			changed = true;
        		if(thisWidget.lastBounds.getSouthWest().lng() != bounds.getSouthWest().lng())
        			changed = true;
        	}
        	else {
        		changed = true;
        	}
        	
        	if(changed) {
               
                var selocation = new Object();
                selocation.units = "WGS84";
                selocation.elevation = 0.0;
                selocation.latitude = bounds.getSouthWest().lat();
                selocation.longitude = bounds.getNorthEast().lng();

                thisWidget.setProperty('SEBoundary', selocation);

                var nwlocation = new Object();
                nwlocation.units = "WGS84";
                nwlocation.elevation = 0.0;
                nwlocation.latitude = bounds.getNorthEast().lat();
                nwlocation.longitude = bounds.getSouthWest().lng();

                thisWidget.setProperty('NWBoundary', nwlocation);
                
                thisWidget.lastBounds = bounds;
				thisWidget.setProperty('FilteredDataBoundByView', thisWidget.getDataMarkersBoundByMap(thisWidget.lastData, nwlocation, selocation));                   
                thisWidget.jqElement.triggerHandler('BoundsChanged');                    
        	}
        });
        
    };

    this.moveSelectionMarker = function (newLocation) {
        if (newLocation !== undefined) {
            var newPoint = new BMap.Point(newLocation.longitude, newLocation.latitude);

            if (thisWidget.getProperty('ShowSelectionMarker') === true) {

                if (thisWidget.selectionMarker !== null) {
                    thisWidget.selectionMarker.setPosition(newPoint);
                } else {
                    var selMarkerOpt = {
                        icon: thisWidget.selectionMarkerStyle.image,
                        title: "Selection"
                    };

                    thisWidget.selectionMarker = new BMap.Marker(newPoint, selMarkerOpt);
                }
            }

            this.map.setCenter(newPoint);
        }
    };
    
    this.cleanupTooltipMashup = function () {

    };
    
    this.getDataMarkersBoundByMap = function (data, nwBound, seBound)
	{
		var filteredRows = [];
		var filteredInfoTable = TW.InfoTableUtilities.CloneInfoTable({ "dataShape" : { "fieldDefinitions" : thisWidget.filteredDataDatashape}, "rows" : thisWidget.lastData });
		for(var i = 0; i < thisWidget.lastData.length; i++)
		{
			var dataRow = thisWidget.lastData[i]
			var locationOfNode = dataRow[thisWidget.getProperty('LocationField')];
			var lowerLongitude = nwBound.longitude;
			var upperLongitude = seBound.longitude;
			if((seBound.longitude * nwBound.longitude) < 0)
			{
				if((nwBound.longitude * locationOfNode.longitude) > 0)
				{
					upperLongitude = 180;
				}
				else
				{
					lowerLongitude = -180;
				}
			}
			else
			{
				if(lowerLongitude > upperLongitude)
				{
					filteredRows.push(dataRow);
				}
			}
			if((locationOfNode.latitude > seBound.latitude && locationOfNode.latitude < nwBound.latitude) && (locationOfNode.longitude > lowerLongitude && locationOfNode.longitude < upperLongitude))
			{
				filteredRows.push(dataRow);
			}
		}
		filteredInfoTable.rows = filteredRows;
		return filteredInfoTable;
	};

    this.serviceInvoked = function (serviceName) {
        if (serviceName === 'AutoZoom') {
            setTimeout(function () {
                autofitMap();
            }, 1);
        } else {
            TW.log.error('Baidu map widget, unexpected serviceName invoked "' + serviceName + '"');
        }
    };

    this.beforeDestroy = function () {

    };

    this.cleanupRouteOverlays = function () {
        try {
            if (thisWidget.routePolyline !== undefined && this.routePolyline !== null) {
                thisWidget.map.removeOverlay(thisWidget.routePolyline);
                thisWidget.routePolyline = null;
                delete this.routePolyline;
            }
        }
        catch (destroyErr) {
//        	alert('error in destroy routePolyline');
        }
    };

    this.cleanupPlannedRouteOverlays = function () {
        try {
            if (this.plannedRoutePolyline !== undefined && this.plannedRoutePolyline !== null) {
                thisWidget.map.removeOverlay(thisWidget.plannedRoutePolyline);
                this.plannedRoutePolyline = null;
                delete this.plannedRoutePolyline;
            }
        }
        catch (destroyErr) {
//        	alert('error in destroy plannedRoutePolyline');
        }
    };

    this.cleanupRegionOverlays = function () {
        try {
            if (this.currentRegions !== undefined && this.currentRegions !== null) {
                for (var x = 0; x < this.currentRegions.length; x++) {
                    thisWidget.map.removeOverlay(this.currentRegions[x]);
                    this.currentRegions[x] = null;
                }

                this.currentRegions = {};
            }
        }
        catch (err) {
            TW.log.error('error cleanupRegionOverlays', err);
//        	alert('error in destroy routePolyline');
        }
    };

    this.cleanupMapOverlays = function () {
        thisWidget.map.clearOverlays();
    };

    this.clearSelectedRegions = function () {
        thisWidget.selectedRegionRows = [];
        for (var regionNo = 0; regionNo < thisWidget.currentRegions.length; regionNo++) {
            var region = thisWidget.currentRegions[regionNo];
            region.setFillColor(region._assignedFillColor);
            region.setStrokeColor(region._assignedStrokeColor);
            region.setStrokeWeight(region._assignedStrokeWeight);
            region._isSelected = false;
        }
    };

    this.getAllPoints = function(){
        var points = [];
        return points.concat(thisWidget.positionData, thisWidget.routeData, thisWidget.plannedRouteData, thisWidget.regionData, thisWidget.regionLocationData);
    };

    this.regionClickEventListener = function (e) {
        thisWidget.setSelectedRegion(this.rowNumber);
    };

    this.regionMouseOverEventListener = function (e) {
        var region = this;
        if (region.rowNumber != lastRegionNumber) {
            regionInfoWindow.setContent(region.title);
            lastRegionNumber = region.rowNumber;
        }
        if (!regionInfoWindow.isOpen()) {
            thisWidget.map.openInfoWindow(regionInfoWindow, region._tooltipCenter);
        }
    };

    this.setSelectedRegion = function (selectedRow) {
        var isMultiselect = thisWidget.properties['RegionMultiSelect'];
        var selectedRegion;
        for (var regionNo = 0; regionNo < thisWidget.currentRegions.length; regionNo++) {
            var currentRegion = thisWidget.currentRegions[regionNo];
            if (currentRegion.rowNumber === selectedRow) {
                selectedRegion = currentRegion;
                break;
            }
        }

        if (selectedRegion !== undefined) {
            if (selectedRegion._isSelected) {
                if (isMultiselect) {
                    TW.removeElementFromArray(thisWidget.selectedRegionRows, selectedRow);
                    selectedRegion._isSelected = false;
                    selectedRegion.setFillColor(selectedRegion._assignedFillColor);
                    selectedRegion.setStrokeColor(selectedRegion._assignedStrokeColor);
                    selectedRegion.setStrokeWeight(selectedRegion._assignedStrokeWeight);
                    if (!thisWidget.ignoreRegionSelectionEvent) {
                        thisWidget.updateSelection('RegionData', thisWidget.selectedRegionRows);
                    }
                }
            }
            else {
                if (!isMultiselect) {
                    thisWidget.clearSelectedRegions();
                    thisWidget.selectedRegionRows = [selectedRow];
                }
                else
                    thisWidget.selectedRegionRows.push(selectedRow);

                selectedRegion._isSelected = true;
                selectedRegion.setFillColor(thisWidget.selectedRegionStyle.backgroundColor);
                selectedRegion.setStrokeColor(thisWidget.selectedRegionStyle.lineColor);
                selectedRegion.setStrokeWeight(parseInt(thisWidget.selectedRegionStyle.lineThickness));
                if (!thisWidget.ignoreRegionSelectionEvent) {
                    thisWidget.updateSelection('RegionData', thisWidget.selectedRegionRows);
                }
            }
        }
    };

	this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {

        if (propertyName == "Data") {
            thisWidget.ignoreSelectionEvent = true;

            thisWidget.clearSelectedMarkers();

            var nSelectedRows = selectedRowIndices.length;

            for (var selectedRowIndex = 0; selectedRowIndex < nSelectedRows;selectedRowIndex++) {
                thisWidget.setSelectedMarker(selectedRowIndices[selectedRowIndex]);
            }
            
            thisWidget.ignoreSelectionEvent = false;
        }

        if (propertyName == "RegionData") {	
            thisWidget.ignoreRegionSelectionEvent = true;

            thisWidget.clearSelectedRegions();

            var nSelectedRows = selectedRowIndices.length;

            for (var selectedRowIndex = 0; selectedRowIndex < nSelectedRows;selectedRowIndex++) {
                thisWidget.setSelectedRegion(selectedRowIndices[selectedRowIndex]);
            }
            
            thisWidget.ignoreRegionSelectionEvent = false;
        }

    };
	
    this.updateProperty = function (updatePropertyInfo) {
        if (!thisWidget.haveBaiduMap) { return; }

        var zoomOnDataRefresh = true;

        switch( autoZoomBehavior )  {
            case 'disable-on-user-pan-zoom':
                if( userHasPannedOrZoomedSinceAutoZoom === true ) {
                    zoomOnDataRefresh = false;
                }
                break;
            case 'only-when-autozoom-invoked':
                zoomOnDataRefresh = false;
                break;
            case 'only-initial-data':
                zoomOnDataRefresh = initialData;
                initialData = false;
                break;
            default:
                zoomOnDataRefresh = true;
        }

        if (updatePropertyInfo.TargetProperty === 'Zoom') {
            var zoom = parseInt(updatePropertyInfo.RawSinglePropertyValue);
            this.map.setZoom(zoom);
        } else if (updatePropertyInfo.TargetProperty === 'SelectedLocation') {
            var location = updatePropertyInfo.RawSinglePropertyValue;

            if (location != undefined) {
                if (location.latitude != 0 && location.longitude != 0 && location.latitude != undefined && location.longitude != undefined) {
                    this.moveSelectionMarker(location);
                    thisWidget.setProperty('SelectedLocation', location);
                }
            }

            return;
        } else if (updatePropertyInfo.TargetProperty === 'RouteData') {
            var showRoute = this.getProperty('ShowRoute');
            if (showRoute) {
                thisWidget.routeDataBounds = new BMap.Bounds();

                var dataRows = updatePropertyInfo.ActualDataRows;

                this.cleanupRouteOverlays();

                var locationField = this.getProperty('RouteLocationField');

                var nRows = dataRows.length;
                thisWidget.routeData = [];
                for (var rowNumber = 0; rowNumber < nRows; rowNumber++) {
                    var row = dataRows[rowNumber];
                    var thisLocation = row[locationField];
                    if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                        var latlng = new BMap.Point(thisLocation.longitude, thisLocation.latitude);
                        thisWidget.routeData.push(latlng);
                        this.routeDataBounds.extend(latlng);
                    }
                }

                if (thisWidget.routeData.length > 1) {
                    var line = this.routePolyline = new BMap.Polyline(thisWidget.routeData, {
                        strokeStyle: 'solid',
                        strokeWeight: parseInt(thisWidget.routeStyle.lineThickness),
                        strokeColor: thisWidget.routeStyle.lineColor,
                        strokeOpacity: 1.0 });
                    thisWidget.map.addOverlay(line);
                }

                if (zoomOnDataRefresh ) {
                    thisWidget.map.setViewport(thisWidget.routeData);
                }
            }
        } else if (updatePropertyInfo.TargetProperty === 'PlannedRouteData') {
            var showRoute = this.getProperty('ShowPlannedRoute');

            if (showRoute) {
                this.plannedRouteDataBounds = new BMap.Bounds();

                var dataRows = updatePropertyInfo.ActualDataRows;

                this.cleanupPlannedRouteOverlays();

                var locationField = this.getProperty('PlannedRouteLocationField');

                thisWidget.plannedRouteData = [];
                var nRows = dataRows.length;

                for (var rowNumber = 0; rowNumber < nRows; rowNumber++) {
                    var row = dataRows[rowNumber];
                    var thisLocation = row[locationField];
                    if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                        var latlng = new BMap.Point(thisLocation.longitude, thisLocation.latitude);
                        thisWidget.plannedRouteData.push(latlng);
                        this.plannedRouteDataBounds.extend(latlng);
                    }
                }

                if (thisWidget.plannedRouteData.length > 1) {

                    var line = this.plannedRoutePolyline = new BMap.Polyline(thisWidget.plannedRouteData, {
                        strokeStyle: 'solid',
                        strokeWeight: parseInt(thisWidget.plannedRouteStyle.lineThickness),
                        strokeColor: thisWidget.plannedRouteStyle.lineColor,
                        strokeOpacity: 1.0 });
                    thisWidget.map.addOverlay(line);

                }

                if (zoomOnDataRefresh ) {
                    thisWidget.map.setViewport(thisWidget.plannedRouteData);
                }
            }
        } else if (updatePropertyInfo.TargetProperty === 'RegionData') {
            var tooltipField1 = this.getProperty('RegionTooltipField1');
            var tooltipLabel1 = this.getProperty('RegionTooltipLabel1');
            var tooltipField2 = this.getProperty('RegionTooltipField2');
            var tooltipLabel2 = this.getProperty('RegionTooltipLabel2');
            var tooltipField3 = this.getProperty('RegionTooltipField3');
            var tooltipLabel3 = this.getProperty('RegionTooltipLabel3');
            var tooltipField4 = this.getProperty('RegionTooltipField4');
            var tooltipLabel4 = this.getProperty('RegionTooltipLabel4');
            var showRegions = this.getProperty('ShowRegions');
            var showRegionTooltips = this.getProperty('ShowRegionTooltips');

            if (showRegions) {
                this.regionDataBounds = new BMap.Bounds();

                var dataRows = updatePropertyInfo.ActualDataRows;

                var enableRegionSelection = this.getProperty('EnableRegionSelection');

                this.cleanupRegionOverlays();

                var locationsField = this.getProperty('RegionLocationsField');
                var locationField = this.getProperty('RegionLocationField');
                var fillOpacity = this.getProperty('RegionFillOpacity');

                thisWidget.currentRegions = [];
                thisWidget.regionData = [];

                var nRows = dataRows.length;

                for (var rowNumber = 0; rowNumber < nRows; rowNumber++) {
                    var row = dataRows[rowNumber];
                    var locationTable = row[locationsField];
                    if(locationTable !== undefined) {
                        var RegionLatLngList = [];
                        var regionDataRows = locationTable.rows;
                        var nRegionRows = regionDataRows.length;

                        var polygonBounds = new BMap.Bounds();

                        for (var regionRowNumber = 0; regionRowNumber < nRegionRows; regionRowNumber++) {
                            var regionRow = regionDataRows[regionRowNumber];
                            var thisLocation = regionRow[locationField];
                            if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                                var latlng = new BMap.Point(thisLocation.longitude, thisLocation.latitude);
                                RegionLatLngList.push(latlng);
                                thisWidget.regionData.push(latlng);
                                thisWidget.regionDataBounds.extend(latlng);
                                polygonBounds.extend(latlng);
                            }
                        }

                        if (RegionLatLngList.length > 1) {

                            var hasRegionFormatting = thisWidget.properties['RegionFormatting'] !== undefined;

                            var formatStyle = thisWidget.regionStyle;

                            if (hasRegionFormatting) {
                                formatStyle = TW.getStyleFromStateFormatting({ DataRow: row, StateFormatting: thisWidget.properties['RegionFormatting'] });
                            }

                            var regionPolygon = new BMap.Polygon(RegionLatLngList, {
                                strokeColor: formatStyle.lineColor,
                                strokeWeight: parseInt(formatStyle.lineThickness),
                                strokeOpacity: 1.0
                            });
                            regionPolygon.setFillColor(formatStyle.backgroundColor);
                            regionPolygon.setFillOpacity(fillOpacity);
                            thisWidget.map.addOverlay(regionPolygon);

                            regionPolygon._assignedFillColor = formatStyle.backgroundColor;
                            regionPolygon._assignedStrokeColor = formatStyle.lineColor;
                            regionPolygon._assignedStrokeWeight = parseInt(formatStyle.lineThickness);

                            regionPolygon.rowNumber = rowNumber;
                            regionPolygon.rowData = row;
                            regionPolygon._isSelected = false;
                            regionPolygon._tooltipCenter = polygonBounds.getCenter();

                            if (enableRegionSelection) {
                                regionPolygon.addEventListener('click', this.regionClickEventListener);
                            }

                            this.currentRegions.push(regionPolygon);

                            if(showRegionTooltips) {
                                var title = '';

                                if (tooltipField1 !== undefined && tooltipField1 !== '') {
                                    if (tooltipLabel1 !== undefined && tooltipLabel1 !== '')
                                        title = title + tooltipLabel1 + ' : ';
                                    else
                                        title = title + tooltipField1 + ' : ';

                                    title = title + row[tooltipField1];
                                }

                                if (tooltipField2 !== undefined && tooltipField2 !== '') {
                                    if (title.length > 0)
                                        title = title + '<BR>';

                                    if (tooltipLabel2 !== undefined && tooltipLabel2 !== '')
                                        title = title + tooltipLabel2 + ' : ';
                                    else
                                        title = title + tooltipField2 + ' : ';

                                    title = title + row[tooltipField2];
                                }

                                if (tooltipField3 !== undefined && tooltipField3 !== '') {
                                    if (title.length > 0)
                                        title = title + '<BR>';

                                    if (tooltipLabel3 !== undefined && tooltipLabel3 !== '')
                                        title = title + tooltipLabel3 + ' : ';
                                    else
                                        title = title + tooltipField3 + ' : ';

                                    title = title + row[tooltipField3];
                                }

                                if (tooltipField4 !== undefined && tooltipField4 !== '') {
                                    if (title.length > 0)
                                        title = title + '<BR>';

                                    if (tooltipLabel4 !== undefined && tooltipLabel4 !== '')
                                        title = title + tooltipLabel4 + ' : ';
                                    else
                                        title = title + tooltipField4 + ' : ';

                                    title = title + row[tooltipField4];
                                }

                                if (title.length > 0) {
                                    regionPolygon.title = title;
                                    regionPolygon.addEventListener('mouseover', this.regionMouseOverEventListener);
                                }
                            }

                        }

                    }
                }

                // Autofit if we have more than one data point

                if (zoomOnDataRefresh) {
                    thisWidget.map.setViewport(thisWidget.regionData);
                }
            }
        } else if (updatePropertyInfo.TargetProperty === 'Data') {
        	dataInfotable = {
                dataShape: {
                    fieldDefinitions: updatePropertyInfo.DataShape
                },
                rows: []
            };
            this.dataBounds = new BMap.Bounds();
            this.selectedRows = [];
            this.currentMarkers = [];

            var dataRows = updatePropertyInfo.ActualDataRows;

            lastData = dataRows;
            var nwlocation = thisWidget.getProperty("NWBoundary");
			var selocation = thisWidget.getProperty("SEBoundary");
            thisWidget.setProperty('FilteredDataBoundByView', thisWidget.getDataMarkersBoundByMap(thisWidget.lastData, nwlocation, selocation));
            
            this.cleanupMapOverlays();

            var locationField = this.getProperty('LocationField');
            var tooltipField1 = this.getProperty('TooltipField1');
            var tooltipLabel1 = this.getProperty('TooltipLabel1');
            var tooltipField2 = this.getProperty('TooltipField2');
            var tooltipLabel2 = this.getProperty('TooltipLabel2');
            var tooltipField3 = this.getProperty('TooltipField3');
            var tooltipLabel3 = this.getProperty('TooltipLabel3');
            var tooltipField4 = this.getProperty('TooltipField4');
            var tooltipLabel4 = this.getProperty('TooltipLabel4');
            thisWidget.positionData = [];
            var showMarkers = this.getProperty('ShowMarkers');
            var showMarkerTooltips = this.getProperty('ShowMarkerTooltips');

            if (showMarkerTooltips == null || showMarkerTooltips == undefined) {
                showMarkerTooltips = true;
            }

            var enableMarkerSelection = this.getProperty('EnableMarkerSelection');

            var nRows = dataRows.length;

            for (var rowNumber = 0; rowNumber < nRows; rowNumber++) {
                var row = dataRows[rowNumber];
                var thisLocation = row[locationField];
                if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                    var latlng = new BMap.Point(thisLocation.longitude, thisLocation.latitude);
                    thisWidget.positionData.push(latlng);

                    if (showMarkers) {

                        var markerProps = {
                            position: latlng
                        };

                        if(showMarkerTooltips) {
                            var title = '';

                            if (tooltipField1 !== undefined && tooltipField1 !== '') {
                                if (tooltipLabel1 !== undefined && tooltipLabel1 !== '')
                                    title = title + tooltipLabel1 + ' : ';
                                else
                                    title = title + tooltipField1 + ' : ';

                                title = title + row[tooltipField1];
                            }

                            if (tooltipField2 !== undefined && tooltipField2 !== '') {
                                if (title.length > 0)
                                    title = title + '\n';

                                if (tooltipLabel2 !== undefined && tooltipLabel2 !== '')
                                    title = title + tooltipLabel2 + ' : ';
                                else
                                    title = title + tooltipField2 + ' : ';

                                title = title + row[tooltipField2];
                            }

                            if (tooltipField3 !== undefined && tooltipField3 !== '') {
                                if (title.length > 0)
                                    title = title + '\n';

                                if (tooltipLabel3 !== undefined && tooltipLabel3 !== '')
                                    title = title + tooltipLabel3 + ' : ';
                                else
                                    title = title + tooltipField3 + ' : ';

                                title = title + row[tooltipField3];
                            }

                            if (tooltipField4 !== undefined && tooltipField4 !== '') {
                                if (title.length > 0)
                                    title = title + '\n';

                                if (tooltipLabel4 !== undefined && tooltipLabel4 !== '')
                                    title = title + tooltipLabel4 + ' : ';
                                else
                                    title = title + tooltipField4 + ' : ';

                                title = title + row[tooltipField4];
                            }

                            if (title.length > 0 && !isMashupTooltipConfigured) {
                                markerProps.title = title;
                            }
                        }

                        var markerField = thisWidget.properties['MarkerField'];
                        var hasFormatting = thisWidget.properties['MarkerFormatting'] !== undefined;

                        if (hasFormatting) {
                            var formatStyle = TW.getStyleFromStateFormatting({ DataRow: row, StateFormatting: thisWidget.properties['MarkerFormatting'] });
                            if (formatStyle.styleDefinitionName !== undefined) {
                                markerProps.icon = formatStyle.image;
                            } else {
                                markerProps.icon = thisWidget.markerStyle.image;
                            }
                        } else {
                            markerProps.icon = thisWidget.markerStyle.image;
                        }

                        if (markerField !== undefined && markerField !== '') {
                            var markerImagePath = row[markerField];
                            if(markerImagePath !== undefined && markerImagePath !== '') {
                                markerProps.icon = markerImagePath;
                            }
                        }

                        var iconImg = createIcon({ image:markerProps.icon, w:thisWidget.markerWidth, h:thisWidget.markerHeight, l:0, t:0, x:6, lb:5 });
                        var markerOpt = {
                            icon: iconImg,
                            title: markerProps.title
                        };

                        var marker = new BMap.Marker(latlng, markerOpt);
                        marker.rowNumber = rowNumber;
                        marker.rowData = row;
                        marker._isSelected = false;
                        marker._assignedIcon = iconImg;
                        thisWidget.map.addOverlay(marker);

                        var markerLayerField = thisWidget.properties['MarkerLayerField'];

                        this.currentMarkers.push(marker);

                        this.markerLookup.push({ latlng : latlng, marker : marker});

                        // This funky code is because we are in a loop and need to do some closure magic

                        if (isMashupTooltipConfigured) {
                            marker.addEventListener("mouseover", handleMarkerMouseover);
                        }
                        if (enableMarkerSelection) {
                            marker.addEventListener("click", handleMarkerClick);
                            marker.addEventListener("dblclick", handleMarkerDoubleClick);
                        }
                    }

                    this.dataBounds.extend(latlng);
                }
            }

            var showPathBetweenMarkers = this.getProperty('ShowPathBetweenMarkers');
            if (thisWidget.positionData.length > 1 && showPathBetweenMarkers) {
                var line = this.polyline = new BMap.Polyline(thisWidget.positionData, {
                    strokeStyle: 'solid',
                    strokeWeight: parseInt(thisWidget.pathStyle.lineThickness),
                    strokeColor: thisWidget.pathStyle.lineColor,
                    strokeOpacity: 1.0 });
                thisWidget.map.addOverlay(line);

                if (this.getProperty('ShowEndMarker')) {
                    this.endMarker = new BMap.Marker(thisWidget.positionData[thisWidget.positionData.length - 1], {
                        icon: createIcon({ image: this.endMarkerStyle.image, w:thisWidget.markerWidth, h:thisWidget.markerHeight, l:0, t:0, x:6, lb:5 }),
                        title: "End"
                    });
                    thisWidget.map.addOverlay(this.endMarker);
                }

                if (this.getProperty('ShowStartMarker')) {
                    this.startMarker = new BMap.Marker(thisWidget.positionData[0], {
                        icon: createIcon({ image: this.startMarkerStyle.image, w:thisWidget.markerWidth, h:thisWidget.markerHeight, l:0, t:0, x:6, lb:5 }),
                        title: "Start"
                    });
                    thisWidget.map.addOverlay(this.startMarker);
                }

            }

            if (zoomOnDataRefresh) {
                thisWidget.map.setViewport(thisWidget.positionData);
            }

            // Finally, handle any pre-selected markers
            thisWidget.clearSelectedMarkers();
            var selectedRowIndices = updatePropertyInfo.SelectedRowIndices;

            if (selectedRowIndices !== undefined) {
                var nSelectedRows = selectedRowIndices.length;

                for (var selectedRowIndex = 0; selectedRowIndex < nSelectedRows; selectedRowIndex++) {
                    thisWidget.setSelectedMarker(selectedRowIndices[selectedRowIndex]);
                }
            }
        }
    };
};
